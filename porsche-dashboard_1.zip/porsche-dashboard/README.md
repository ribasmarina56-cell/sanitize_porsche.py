# Dashboard Porsche: do dado bruto às respostas de negócio

Dashboard interativa (HTML único, sem build) com 100 vendas de Porsche, publicada no GitHub Pages.

**Demo:** `https://SEU-USUARIO.github.io/NOME-DO-REPO/`

## O caminho do dado

1. **Base bruta** com datas, preços, milhas e status em formatos misturados (`$121k`, `KM 18,900`, `DELIVERD`, `2024-02-30`).
2. **Higienização** com `scripts/sanitize_porsche.py`, que segue as regras de `docs/schema.md`. Rodei o script sobre as colunas brutas da planilha e as 8 colunas sanitizadas saíram idênticas às da base. Cada coluna limpa (`...Sanitized`) é inserida logo após a coluna de origem, e o que não dá para corrigir vira `INVALID`. O resultado está em `data/porsche_database_sanitized.xlsx`.
3. **Preparação para a dashboard** em `data/vendas_porsche_limpa.csv`:
   - uso só as colunas sanitizadas;
   - modelos agrupados em 6 famílias (911, 718, Cayenne, Macan, Panamera, Taycan);
   - status agrupados em Entregue, Em andamento e Cancelada;
   - nomes de vendedores padronizados.
4. **Dashboard** em `index.html`, com filtros e perguntas de negócio.

## Perguntas de negócio

- Qual família gera mais receita?
- Qual estado lidera?
- Qual forma de pagamento é a mais valiosa?
- Qual modelo tem o maior ticket médio?
- Quem é o vendedor líder?
- Zero km vale mais que seminovo?
- Quanto se perde com cancelamentos?

## Decisões e limites dos dados

- 24 das 100 vendas têm data inválida. Elas ficam fora do gráfico mensal e aparecem no filtro "Sem data válida".
- Há vendas datadas depois de hoje (até out/2027). Foram mantidas como estão na base.
- Receita e ticket médio não contam vendas canceladas.
- A base não tem custo, então não há margem.

O prompt usado no ChatGPT Canvas está em `docs/prompt_canvas.md`.

## Comparação: ChatGPT Canvas × agente com skill

| Critério | ChatGPT Canvas | Agente com skill |
|---|---|---|
| Entrada | Excel já higienizado + prompt | Excel bruto + skill de higienização |
| Filtros funcionando | | |
| Perguntas respondidas | | |
| Tratamento de datas inválidas | | |
| Visual / identidade | | |
| Iterações até o resultado final | | |

## Publicar no GitHub Pages

1. Suba esta pasta para um repositório.
2. Vá em *Settings → Pages*.
3. Em *Source*, escolha *Deploy from a branch*, depois `main` e `/ (root)`.
