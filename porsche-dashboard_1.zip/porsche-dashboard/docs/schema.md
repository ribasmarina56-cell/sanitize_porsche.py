# Porsche Sales Sanitization Schema

Regras de higienização usadas por `scripts/sanitize_porsche.py`.

## Colunas de entrada

| Coluna | Descrição | Exemplos brutos |
|---|---|---|
| `sale_id` | ID único da venda | `1`, `86` |
| `sale_date` | Data bruta | `2024-13-05`, `02/05/24`, `July 15th, 2024` |
| `customer_name` | Cliente | `John  Smith`, `MARY johnson` |
| `porsche_model` | Modelo e versão | `911 Carrera`, `Macan Electric` |
| `model_year` | Ano do modelo | `2023`, `20-20`, `two thousand twenty two` |
| `sale_price` | Preço em USD, formatos variados | `$985,000.00`, `188k USD` |
| `vehicle_mileage` | Quilometragem em milhas ou km | `12,500 miles`, `KM 15.200`, `new` |
| `payment_method` | Forma de pagamento | `CreditCard`, `bank-transfer` |
| `city` | Cidade | `new york`, `San Jose` |
| `state` | Estado dos EUA | `ny`, `California` |
| `salesperson` | Vendedor | `William  Clark`, `SARAH lee` |
| `delivery_status` | Status da entrega | `Delivered!!!`, `in-transit`, `DELIVERD` |

## Colunas de saída

| Origem | Saída | Formato |
|---|---|---|
| `sale_date` | `SaleDateSanitized` | `YYYY-MM-DD` ou `INVALID` |
| `porsche_model` | `PorscheModelSanitized` | Nome canônico do modelo |
| `model_year` | `ModelYearSanitized` | Ano com 4 dígitos ou `INVALID` |
| `sale_price` | `SalesPriceSanitized` | Valor em USD com duas casas |
| `vehicle_mileage` | `VehicleMileageSanitized` | Milhas inteiras |
| `payment_method` | `PayMethodSanitized` | Rótulo controlado |
| `city` | `CitySanitized` | Cidade em title case |
| `state` | `StateSanitized` | Sigla USPS ou `INVALID` |
| `delivery_status` | `DeliveryStatusSanitized` | Rótulo controlado |

## Regras

- **Datas:** normalizar para `YYYY-MM-DD`. Aceitar `YYYY-MM-DD`, `YYYY/MM/DD`, `YYYY.MM.DD`, `MM/DD/YYYY`, `MM/DD/YY`, `MM-DD-YY`, `Month DDth, YYYY` e `Mon DDth YYYY`. Datas de calendário inexistentes (`2024-13-05`, `2024-02-30`, `April 31st, 2024`) viram `INVALID`.
- **Modelos:** normalizar para title case canônico, preservando as versões válidas (911 Carrera, 911 Turbo S, 718 Cayman GT4 RS, Cayenne E-Hybrid, Macan Electric, Panamera 4 E-Hybrid, Taycan Cross Turismo e as demais da lista do script). Modelos desconhecidos recebem title case e não são descartados.
- **Ano do modelo:** quatro dígitos. Converter `twenty twenty four` e `20-24`. Fora de 1990 a 2035 vira `INVALID`.
- **Preço:** decimal em USD, sem símbolos nem texto. `$645k` vira `645000.00` e `eighty two thousand USD` vira `82000.00`.
- **Quilometragem:** milhas inteiras. `zero miles`, `new` e `0 mi` viram `0`. Valores marcados como `KM` são convertidos com 1 km = 0,621371 milha, arredondando.
- **Pagamento:** Credit Card, Debit Card, Bank Transfer, Wire Transfer, Financing, Lease, Cash, ACH Payment ou Crypto Payment. Desconhecidos recebem title case.
- **Cidade:** title case, preservando pontuação como `St. Louis`.
- **Estado:** sigla USPS de duas letras, aceitando nome ou sigla em qualquer caixa. Desconhecido vira `INVALID`.
- **Status:** Delivered, Pending, In Transit, Cancelled, Awaiting Delivery, Awaiting Pickup, Pending Approval, Pending Review, Shipped ou Awaiting Review. Trata pontuação, caixa, hífens e o erro `DELIVERD`.

## Verificações de qualidade

- Nenhuma coluna original é removida.
- Cada coluna sanitizada fica logo após a sua coluna de origem.
- Nenhum valor em branco nas colunas sanitizadas. Use `INVALID` quando não for possível normalizar com segurança.
