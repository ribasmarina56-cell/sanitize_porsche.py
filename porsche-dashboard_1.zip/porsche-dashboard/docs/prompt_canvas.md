# Prompt para o ChatGPT Canvas

Anexe `data/porsche_database_sanitized.xlsx` e envie:

> Crie, no Canvas, uma dashboard interativa em um único arquivo HTML (CSS e JavaScript inline) a partir das 100 vendas da planilha anexa.
>
> Use as colunas `...Sanitized`. Agrupe os modelos em famílias (911, 718, Cayenne, Macan, Panamera, Taycan) e os status em Entregue, Em andamento e Cancelada. Datas `INVALID` ficam fora do gráfico mensal, mas a venda continua nos demais indicadores.
>
> Filtros: família, estado, forma de pagamento, status e ano da venda, todos atualizando a página inteira.
>
> Indicadores: receita, número de vendas, ticket médio e percentual de canceladas. Receita e ticket não contam vendas canceladas.
>
> Gráficos: receita por mês, por família, por estado (top 8), por forma de pagamento e status da entrega.
>
> Responda na página, recalculando com os filtros: qual família gera mais receita, qual estado lidera, qual forma de pagamento é a mais valiosa, qual modelo tem o maior ticket médio, quem é o vendedor líder, se zero km vale mais que seminovo e quanto se perde com cancelamentos.
>
> Visual sóbrio, inspirado na identidade da Porsche, com vermelho como único destaque, responsivo e legível em modo claro e escuro.
